mkdir -p /app/models

chmod 777 /app/models

python mL_app.py
