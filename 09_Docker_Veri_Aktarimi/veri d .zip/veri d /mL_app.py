import pickle
import os
from pathlib import Path
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import numpy as np


def train_model():
    # Modeli eğitip kaydedecek fonksiyon
    iris = load_iris()
    X = iris.data
    y = iris.target

    print("Veri seti yüklendi. Eğitim ve test verileri ayrılıyor...")

    # Veriyi eğitim ve test setlerine ayır
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # modeli oluştur
    print("Model oluşturuluyor...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)

    # modeli eğit
    print("Model eğitiliyor...")
    model.fit(X_train, y_train)

    # modelle tahminler yap
    print("Model test verisi üzerinde tahmin yapıyor...")
    y_pred = model.predict(X_test) # train ile modeli eğittikten sonra test verisi üzerinde tahminler yapıyoruz

    # perfonması ölç
    print("Model performansı ölçülüyor...")
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Model Accuracy: {accuracy}")
    print("\nDetaylı Rapor:")
    print(classification_report(y_test, y_pred))

    # Modeli kaydet
    try:
        model_dir = Path("models")
        model_dir.mkdir(parents=True, exist_ok=True)
        model_path = model_dir / "model.pkl"

        with open(model_path, "wb") as f:
            pickle.dump(model, f)

        absolute_model_path = os.path.abspath(model_path)
        print(f"Model kaydedildi: {absolute_model_path}")

    except Exception as e:
        print(f"Hata: Model kaydedilirken sorun oluştu - {e}")

    return model


def predict_sample(model, iris):
    sample = np.array([[5.1, 3.5, 1.4, 0.2]]) # Örnek veri
    # sample = sample.reshape(1, -1)  # Örneği uygun şekle getir

    prediction = model.predict(sample)
    probabilities = model.predict_proba(sample)

    print(f"Tahmin: {iris.target_names[prediction[0]]}")
    print(f"Olabilirlikler: {probabilities[0]}")


if __name__ == "__main__":
    iris = load_iris()
    model = train_model()
    predict_sample(model, iris)
    print("Model eğitimi ve tahmin tamamlandı.")